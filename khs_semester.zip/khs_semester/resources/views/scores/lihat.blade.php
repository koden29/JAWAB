@extends('layout/main');

@section('title','Nilai Mahasiswa')

@section('container')
<div class="container">
  <div class="row">
    <div class="col-12">
    <h1 class="mt-2">DAFTAR NILAI</h1>

    </div>
  </div>
</div>
@endsection 