@extends('layout/main');

@section('title','KHS')

@section('container')
<div class="container">
  <div class="row">
    <div class="col-10">
    <h1 class="mt-2">Wellcome, world!</h1>  
    </div>
  </div>
</div>
@endsection