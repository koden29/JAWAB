;

<?php $__env->startSection('title','Ubah Data Mata Kuliah'); ?>

<?php $__env->startSection('container'); ?>
<div class="container">
  <div class="row">
    <div class="col-8">

    <h1 class="mt-2">UBAH DATA MATA KULIAH</h1>  
    
    <form method="POST" action="/courses/<?php echo e($course->id_course); ?>">
      <?php echo method_field('patch'); ?>
      <?php echo csrf_field(); ?>
      <div class="mb-3">
        <label for="nama_mk" class="form-label">Nama Mata Kuliah</label>
        <input type="text" class="form-control <?php if ($errors->has('nama_mk')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama_mk'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="nama_mk" placeholder="Masukan Nama Mata Kuliah" name="nama_mk" value="<?php echo e($course->nama_mk); ?>">
      <?php if ($errors->has('nama_mk')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama_mk'); ?>
      <div id="nama_mk" class="invalid-feedback">
        <?php echo e($message); ?>

      </div>
      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
      </div>

      <div class="mb-3">
        <label for="sks" class="form-label">SKS</label>
        <input type="number" class="form-control  <?php if ($errors->has('sks')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('sks'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="sks" placeholder="Masukan SKS" name="sks" value="<?php echo e($course->sks); ?>">
        <?php if ($errors->has('sks')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('sks'); ?>
      <div id="sks" class="invalid-feedback">
        <?php echo e($message); ?>

      </div>
      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
      </div>
      <button type="submit" class="btn btn-primary">Ubah Data!</button>
    </form>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp\htdocs\khs_semester\resources\views/courses/edit.blade.php ENDPATH**/ ?>