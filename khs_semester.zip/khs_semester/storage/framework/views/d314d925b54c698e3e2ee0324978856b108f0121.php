;

<?php $__env->startSection('title','Web Programing DB'); ?>

<?php $__env->startSection('container'); ?>
<div class="container">
  <div class="row">
    <div class="col-8">

    <h1 class="mt-2">TAMBAH NILAI</h1>  
    
    <form method="POST" action="/scores">
      <?php echo csrf_field(); ?>
      <div class="mb-3">
      <label for="namamhs" class="form-label">Nama Mahasiswa</label>
        <select class="form-select" aria-label="Default select example" name = "id">
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($mhs->id); ?>"><?php echo e($mhs->nama); ?> - <?php echo e($mhs->NIM); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>

      <div class="mb-3">
      <label for="namamk" class="form-label">Nama Mata Kuliah</label>
        <select class="form-select" aria-label="Default select example" name="id_course">
        <?php $__currentLoopData = $matkul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($mk->id_course); ?>"><?php echo e($mk->nama_mk); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>

      <div class="mb-3">
        <label for="Nilai" class="form-label">Nilai</label>
        <input type="number" class="form-control  <?php if ($errors->has('nilai')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nilai'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="nilai" placeholder="Masukan Nilai" name="nilai" value="<?php echo e(old('nilai')); ?>">
        <?php if ($errors->has('nilai')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nilai'); ?>
      <div id="nilai" class="invalid-feedback">
        <?php echo e($message); ?>

      </div>
      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
      </div>
      
      <button type="submit" class="btn btn-primary">Tambah Data!</button>
    </form>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp\htdocs\khs_semester\resources\views/scores/create.blade.php ENDPATH**/ ?>