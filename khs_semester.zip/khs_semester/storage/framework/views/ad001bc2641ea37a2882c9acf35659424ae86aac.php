;

<?php $__env->startSection('title','Ubah Data Mahasiswa'); ?>

<?php $__env->startSection('container'); ?>
<div class="container">
  <div class="row">
    <div class="col-8">

    <h1 class="mt-2">UBAH DATA MAHASISWA</h1>  
    
    <form method="POST" action="/students/<?php echo e($student->id); ?>">
      <?php echo method_field('patch'); ?>
      <?php echo csrf_field(); ?>
      <div class="mb-3">
        <label for="nama" class="form-label">Nama</label>
        <input type="text" class="form-control <?php if ($errors->has('nama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="nama" placeholder="Masukan Nama" name="nama" value="<?php echo e($student->nama); ?>">
      <?php if ($errors->has('nama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama'); ?>
      <div id="nama" class="invalid-feedback">
        <?php echo e($message); ?>

      </div>
      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
      </div>

      <div class="mb-3">
        <label for="nim" class="form-label">NIM</label>
        <input type="text" class="form-control  <?php if ($errors->has('nim')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nim'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="nim" placeholder="Masukan NIM" name="nim" value="<?php echo e($student->NIM); ?>">
        <?php if ($errors->has('nim')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nim'); ?>
      <div id="nama" class="invalid-feedback">
        <?php echo e($message); ?>

      </div>
      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
      </div>
      <div class="mb-3">
        <label for="email" class="form-label">Email</label>
        <input type="text" class="form-control" id="email" placeholder="Masukan Email" name="email" value="<?php echo e($student->email); ?>">
      </div>
      <div class="mb-3">
        <label for="jurusan" class="form-label">Jurusan</label>
        <input type="text" class="form-control" id="jurusan" placeholder="Masukan Jurusan" name="jurusan" value="<?php echo e($student->jurusan); ?>">
      </div>
      <button type="submit" class="btn btn-primary">Ubah Data!</button>
    </form>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp\htdocs\khs_semester\resources\views/students/edit.blade.php ENDPATH**/ ?>