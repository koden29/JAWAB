;

<?php $__env->startSection('title','Tambah Data Mata Kuliah'); ?>

<?php $__env->startSection('container'); ?>
<div class="container">
  <div class="row">
    <div class="col-8">

    <h1 class="mt-2">TAMBAH DATA MATA KULIAH</h1>  
    
    <form method="POST" action="/courses">
      <?php echo csrf_field(); ?>
      <div class="mb-3">
        <label for="nama_mk" class="form-label">Mata Kuliah</label>
        <input type="text" class="form-control <?php if ($errors->has('nama_mk')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama_mk'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="nama_mk" placeholder="Masukan Nama Mata Kuliah" name="nama_mk" value="<?php echo e(old('nama_mk')); ?>">
      <?php if ($errors->has('nama_mk')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama_mk'); ?>
      <div id="nama_mk" class="invalid-feedback">
        <?php echo e($message); ?>

      </div>
      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
      </div>

      <div class="mb-3">
        <label for="sks" class="form-label">SKS</label>
        <input type="number" class="form-control  <?php if ($errors->has('sks')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('sks'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="sks" placeholder="Masukan Jumlah SKS" name="sks" value="<?php echo e(old('sks')); ?>">
        <?php if ($errors->has('sks')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('sks'); ?>
      <div id="sks" class="invalid-feedback">
        <?php echo e($message); ?>

      </div>
      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
      </div>
      <button type="submit" class="btn btn-primary">Tambah Data!</button>
    </form>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp\htdocs\khs_semester\resources\views/courses/create.blade.php ENDPATH**/ ?>